
# Standorte definition (user-provided)
$Standort = @{
    AT = @{
        Country = 'Austria'
        Branches = @{
            KL = @{
                City = 'Klagenfurt'
                Prefix = 'ATKL'
                Werk         = @()
                Kostenstelle = 0
            }
            ZL = @{
                City         = 'Klagenfurt'
                Prefix       = 'ATZL'
                Werk         = @()
                Kostenstelle = 0
            }
            MS = @{
                City         = 'Maria Saal'
                Prefix       = 'ATMS'
                Werk         = @()
                Kostenstelle = 0
            }
            VK = @{
                City = 'Völkermarkt'
                Prefix = 'ATVK'
                Werk         = @()
                Kostenstelle = 0
            }
            UB = @{
                City         = 'Unterbergen'
                Prefix       = 'ATUB'
                Werk         = @()
                Kostenstelle = 0
            }
            SV = @{
                City         = 'St.Veit'
                Prefix       = 'ATSV'
                Werk         = @()
                Kostenstelle = 0
            }
        }
    }
    HR = @{
        Country = 'Croatia'
        Branches = @{
            TR = @{
                City = 'Trnovec'
                Prefix = 'HRTR'
                Werk         = @()
                Kostenstelle = 0
            }
            VA = @{
                City   = 'Varazdin'
                Prefix = 'HRVA'
                Werk         = @()
                Kostenstelle = 0
            }
        }
    }
    IN = @{
        Country = 'India'
        Branches = @{
            AB = @{
                City = 'Ahmedabad'
                Prefix = 'INAB'
                Werk         = @(15, 17)
                Kostenstelle = 80000
            }
        }
    }
    IT = @{
        Country  = 'Italy'
        Branches = @{
            UD = @{
                City         = 'Udine'
                Prefix       = 'ITUD'
                Werk         = @()
                Kostenstelle = 0
            }
        }
    }
    US = @{
        Country  = 'America'
        Branches = @{
            GR = @{
                City         = 'Greenville'
                Prefix       = 'USGR'
                Werk         = @()
                Kostenstelle = 0
            }
        }
    }
}

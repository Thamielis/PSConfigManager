
# LocationInventory Package

This package merges your `$Standort` definition with the uploaded data files:

- **BaseData.psd1** — master site info (addresses, languages, company)
- **CountryCodeMap.psd1** — ISO Alpha-2 to Country names
- **Network.psd1** — Networks per Country/City
- **Veeam.psd1** — Site-specific Veeam infrastructure

## Files

- `LocationInventory.psm1` — module with functions
- `Standorte.ps1` — your `$Standort` hashtable (as provided)
- `Build-Locations.ps1` — builds `Locations.json` and `Locations.psd1` using the four data files
- The four PSD1 data files (copied from your upload)

## Usage

Open PowerShell in this folder and run:

```powershell
.\Build-Locations.ps1
```

Outputs:
- `Locations.json` — enriched, runtime-friendly JSON
- `Locations.psd1` — enriched PowerShell data file

### Customize

- Veeam site mapping is applied to **Klagenfurt** by default and shared as a fallback for nearby branches.
  Adjust logic in `Update-BranchDetails` if you need a different mapping.
- Network fallbacks map non-hub branches to **Klagenfurt** when direct city entries are missing.

## Notes

- All variables are in PascalCase as requested.
- Uses Advanced Functions and approved verbs where possible.
- `Export-LocationInventory` includes a PSD1 serializer (no external dependency).

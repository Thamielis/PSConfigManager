
Param(
    [string]$BaseDataPath      = ".\BaseData.psd1",
    [string]$CountryCodeMapPath= ".\CountryCodeMap.psd1",
    [string]$NetworkPath       = ".\Network.psd1",
    [string]$VeeamPath         = ".\Veeam.psd1",
    [string]$OutJsonPath       = ".\Locations.json",
    [string]$OutPsd1Path       = ".\Locations.psd1"
)

# Import module and data
Import-Module -Name "$PSScriptRoot\LocationInventory.psm1" -Force
. "$PSScriptRoot\Standorte.ps1"

$Inventory = New-LocationInventory `
    -Standort $Standort `
    -BaseDataPath $BaseDataPath `
    -CountryCodeMapPath $CountryCodeMapPath `
    -NetworkPath $NetworkPath `
    -VeeamPath $VeeamPath

Export-LocationInventory -Inventory $Inventory -OutJsonPath $OutJsonPath -OutPsd1Path $OutPsd1Path

Write-Host "Done. Files written:" -ForegroundColor Green
Write-Host "  JSON: $OutJsonPath"
Write-Host "  PSD1: $OutPsd1Path"
